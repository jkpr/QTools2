#!/usr/bin/env python

from qtools2.qgui import start_gui

# For PMA-style conversion on Windows, with all directives in XLSForm
start_gui(v2=True, keep_alive=True)
