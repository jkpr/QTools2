#!/usr/bin/env python

from qtools2.qgui import start_gui

# For regular XLSOffline conversion
start_gui(pma=False)
