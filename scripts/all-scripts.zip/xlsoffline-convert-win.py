#!/usr/bin/env python

from qtools2.qgui import start_gui

# For regular XLSOffline conversion on Windows
start_gui(keep_alive=True, regular=True, v2=True)
