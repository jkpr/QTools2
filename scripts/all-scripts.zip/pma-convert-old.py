#!/usr/bin/env python

from qtools2.qgui import start_gui

# For PMA-style conversion, with manual XML editing
start_gui()
