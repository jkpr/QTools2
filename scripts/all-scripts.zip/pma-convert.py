from qtools2.PmaConvert.PmaConvert import run_conversion

if __name__ == '__main__':
    run_conversion()
