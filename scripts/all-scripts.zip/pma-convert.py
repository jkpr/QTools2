#!/usr/bin/env python
from qtools2.qgui import run_conversion

if __name__ == '__main__':
    run_conversion()
