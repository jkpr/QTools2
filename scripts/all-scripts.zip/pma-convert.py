#!/usr/bin/env python

from qtools2.qgui import start_gui

# For PMA-style conversion, with all directives in XLSForm
start_gui(pma=True)
