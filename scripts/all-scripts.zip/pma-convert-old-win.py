#!/usr/bin/env python

from qtools2.qgui import start_gui

# For PMA-style conversion on Windows, with manual XML editing
start_gui(keep_alive=True)
